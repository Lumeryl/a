import 'package:flutt/domain/HelpLine.dart';
import 'package:flutt/pages/tela_violenciaBR.dart';
import 'package:flutter/material.dart';

class TelaInicialWidget extends StatefulWidget {
  final HelpLine helpLine;

  const TelaInicialWidget({Key? key, required this.helpLine}) : super(key: key);

  @override
  State<TelaInicialWidget> createState() => _TelaInicialWidgetState();
}

class _TelaInicialWidgetState extends State<TelaInicialWidget> {
  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        SizedBox(height: 15),
        Padding(
          padding: EdgeInsets.all(8),
          child: ElevatedButton(
            onPressed: () {
              Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (context) => Tela_ViolenciaBR()));
            },
            style: ElevatedButton.styleFrom(
              primary: Color(0xFFECECEC),
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(5),
              ),
            ),
            child: Row(
              children: [
                Image.asset(
                  widget.helpLine.img,
                  height: 150,
                  width: 150,
                ),
                SizedBox(
                  width: 35,
                ),
                Expanded(
                  child: Text(
                    widget.helpLine.tex,
                    style: TextStyle(fontSize: 20, color: widget.helpLine.cor),
                  ),
                ),
                SizedBox(
                  width: 25,
                )
              ],
            ),
          ),
        ),
      ],
    );
  }
}
