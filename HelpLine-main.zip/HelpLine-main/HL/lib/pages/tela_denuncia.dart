import 'package:flutt/db/tela_denunciaDAO.dart';
import 'package:flutter/material.dart';
import 'package:flutt/pages/tela_inicial.dart';

class Tela_Denuncia extends StatelessWidget {
  final dropValue = ValueNotifier('');
  final dropOpcoes = [
    'Violência por raça',
    'Violência de gênero',
    'Violência no trânsito',
    'Violência psicológica',
    'Violência física',
    'Violência sexual',
  ];
  final Future<List> listaDeContainer = TelaDenunciaDAO().findAll();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xff25242e),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (context) => Tela_Inicial()));
            },
          ),
          title: Text(
            'Denúncia',
            style: TextStyle(
              fontSize: 35,
              color: Colors.white,
            ),
          ),
          centerTitle: true,
        ),
        body: ListView(
          children: [
            SizedBox(
              height: 15,
            ),
            Padding(
              padding: EdgeInsets.all(8.0),
              child: ValueListenableBuilder(
                valueListenable: dropValue,
                builder: (BuildContext context, String value, _) {
                  return DropdownButtonFormField(
                    hint: Center(child: Text('Qual o tipo de ocorrência ?')),
                    decoration: InputDecoration(
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(4),
                      ),
                    ),
                    value: (value.isEmpty) ? null : value,
                    onChanged: (escolha) =>
                        dropValue.value = escolha.toString(),
                    items: dropOpcoes
                        .map(
                          (op) => DropdownMenuItem(
                            value: op,
                            child: Text(op),
                          ),
                        )
                        .toList(),
                  );
                },
              ),
            ),
            FutureBuilder(
              future: listaDeContainer,
              builder: ((context, snapshot) {
                if (snapshot.hasData) {
                  List<Widget> lista = (snapshot.data! as List<Widget>);
                  return ListView.builder(
                    itemCount: lista.length,
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return lista[index];
                    },
                  );
                }

                return const Center(child: CircularProgressIndicator());
              }),
            ),
          ],
        ));
  }
}
