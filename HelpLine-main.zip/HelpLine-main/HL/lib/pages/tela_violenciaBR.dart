import 'package:flutt/pages/tela_inicial.dart';
import 'package:flutter/material.dart';
import 'package:flutt/db/tela_violenciaBRDAO.dart';

class Tela_ViolenciaBR extends StatelessWidget {
  Future<List> listaDeDados = TelaViolenciabrDAO().findAll();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xff25242e),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (context) => Tela_Inicial()));
            },
          ),
          title: Text(
            'Dados no Brasil',
            style: TextStyle(
              fontSize: 35,
              color: Colors.white,
            ),
          ),
          centerTitle: true,
        ),
        body: ListView(
          children: [
            SizedBox(
              height: 15,
            ),
            FutureBuilder(
              future: listaDeDados,
              builder: ((context, snapshot) {
                if (snapshot.hasData) {
                  List<Widget> lista = (snapshot.data! as List<Widget>);
                  return ListView.builder(
                    itemCount: lista.length,
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return lista[index];
                    },
                  );
                }

                return const Center(child: CircularProgressIndicator());
              }),
            ),
          ],
        ));
  }
}
