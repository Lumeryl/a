import 'package:flutt/pages/tela_login.dart';
import 'package:flutter/material.dart';

class Tela_Cadastro extends StatelessWidget {
  const Tela_Cadastro({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: Center(
          child: Column(
        children: [
          Container(
            child: Image.asset(
              "images/HelpLine_logo.png",
              alignment: Alignment.topCenter,
            ),
            width: double.infinity,
            height: 275,
            decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(5),
                gradient: LinearGradient(
                  colors: [const Color(0xff13185a), const Color(0xFF8B0000)],
                  stops: [0.8, 1.0],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
                boxShadow: [
                  BoxShadow(
                    color: Colors.grey.withOpacity(0.5),
                    spreadRadius: 5,
                    blurRadius: 7,
                    offset: Offset(0, 1),
                  )
                ]),
          ),
          Padding(
            padding: const EdgeInsets.all(15),
            child: Column(children: [
              SizedBox(
                height: 8,
              ),
              Text("Cadastro", style: TextStyle(fontSize: 40)),
              TextField(
                  decoration: InputDecoration(
                labelText: "e-mail",
                contentPadding: EdgeInsets.symmetric(vertical: 8),
                border:
                    OutlineInputBorder(borderRadius: BorderRadius.circular(10)),
                filled: true,
                fillColor: Colors.grey[200],
                hintStyle: TextStyle(color: Colors.transparent),
                suffixIcon: Icon(Icons.person),
              )),
              SizedBox(
                height: 15,
              ),
              TextField(
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: "Senha",
                    contentPadding: EdgeInsets.symmetric(vertical: 8),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10)),
                    filled: true,
                    fillColor: Colors.grey[200],
                    hintStyle: TextStyle(color: Colors.transparent),
                    suffixIcon: Icon(Icons.lock),
                  )),
              SizedBox(
                height: 15,
              ),
              TextField(
                  obscureText: true,
                  decoration: InputDecoration(
                    labelText: "Confirmar senha",
                    contentPadding: EdgeInsets.symmetric(vertical: 8),
                    border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(10)),
                    filled: true,
                    fillColor: Colors.grey[200],
                    hintStyle: TextStyle(color: Colors.transparent),
                    suffixIcon: Icon(Icons.lock),
                  )),
              SizedBox(height: 5),
              Row(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  TextButton(
                    onPressed: () {
                      Navigator.pushReplacement(
                          context,
                          MaterialPageRoute(
                              builder: (context) => Tela_Login()));
                    },
                    child: Text("Já possui uma conta?",
                        style: TextStyle(
                            color: Color.fromARGB(255, 128, 128, 128))),
                  )
                ],
              ),
              SizedBox(height: 15),
              ElevatedButton(
                onPressed: () {},
                child: Text("Cadastrar"),
                style: ButtonStyle(
                  backgroundColor:
                      MaterialStateProperty.all<Color>(Colors.blue[900]!),
                  foregroundColor:
                      MaterialStateProperty.all<Color>(Colors.white),
                  shape: MaterialStateProperty.all<RoundedRectangleBorder>(
                    RoundedRectangleBorder(
                        borderRadius: BorderRadius.circular(30)),
                  ),
                ),
              ),
            ]),
          ),
        ],
      )),
    );
  }
}
