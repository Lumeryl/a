import 'package:flutt/db/tela_inicialDAO.dart';
import 'package:flutt/widgets/tela_inicial_widget.dart';
import 'package:flutter/material.dart';
import 'package:flutt/pages/tela_login.dart';
import 'package:flutt/domain/HelpLine.dart';

class Tela_Inicial extends StatelessWidget {
  Future<List<HelpLine>> listaDeElem = TelaInicialDAO().findAll();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        appBar: AppBar(
          backgroundColor: Color(0xff13185a),
          leading: IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () {
              Navigator.of(context).pushReplacement(
                  MaterialPageRoute(builder: (context) => Tela_Login()));
            },
          ),
        ),
        body: ListView(
          children: [
            Container(
              height: 65,
              width: 100,
              child: Padding(
                  padding: const EdgeInsets.all(8.0),
                  child: Align(
                    alignment: Alignment.center,
                    child: Text(
                      "Início",
                      style: TextStyle(color: Colors.white, fontSize: 30),
                    ),
                  )),
              color: Color(0xff25242e),
            ),
            SizedBox(
              height: 10,
            ),
            FutureBuilder(
              future: listaDeElem,
              builder: ((context, snapshot) {
                if (snapshot.hasData) {
                  List<HelpLine> lista = (snapshot.data! as List<HelpLine>);
                  return ListView.builder(
                    itemCount: lista.length,
                    physics: const NeverScrollableScrollPhysics(),
                    shrinkWrap: true,
                    itemBuilder: (context, index) {
                      return TelaInicialWidget(helpLine: lista[index]);
                    },
                  );
                }

                return const Center(child: CircularProgressIndicator());
              }),
            ),
          ],
        ));
  }
}
