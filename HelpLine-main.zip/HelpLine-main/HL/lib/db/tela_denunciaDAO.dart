import 'package:flutter/material.dart';

class TelaDenunciaDAO {
  final List<Widget> containers = [
    SizedBox(height: 15),
    Padding(
      padding: EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Local da ocorrência",
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 4),
          TextField(
            maxLines: 2,
            decoration: InputDecoration(
              hintText: "Descreva o local da ocorrência",
              contentPadding: EdgeInsets.symmetric(vertical: 4),
              filled: true,
              fillColor: Colors.grey[200],
            ),
          ),
        ],
      ),
    ),
    SizedBox(
      height: 15,
    ),
    Padding(
      padding: EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            "Detalhes",
            style: TextStyle(
              fontSize: 16,
              fontWeight: FontWeight.bold,
            ),
          ),
          SizedBox(height: 4),
          TextField(
            maxLines: 6,
            decoration: InputDecoration(
              hintText: "Conte mais detalhes da denúncia",
              contentPadding: EdgeInsets.symmetric(vertical: 12),
              filled: true,
              fillColor: Colors.grey[200],
            ),
          ),
        ],
      ),
    ),
    SizedBox(
      height: 15,
    ),
    Container(
      margin: EdgeInsets.symmetric(horizontal: 100),
      child: ElevatedButton(
        onPressed: () {},
        style: ButtonStyle(
          backgroundColor: MaterialStateProperty.all<Color>(Colors.blue[900]!),
          foregroundColor: MaterialStateProperty.all<Color>(Colors.white),
          shape: MaterialStateProperty.all<RoundedRectangleBorder>(
            RoundedRectangleBorder(
              borderRadius: BorderRadius.circular(30),
            ),
          ),
        ),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Text("Enviar"),
            SizedBox(width: 8),
            Icon(
              Icons.report,
            ),
          ],
        ),
      ),
    )
  ];

  Future<List<Widget>> findAll() async {
    await Future.delayed(Duration(seconds: 3));
    return containers;
  }
}
