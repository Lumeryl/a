import 'package:flutt/domain/HelpLine.dart';
import 'package:flutter/material.dart';

class TelaInicialDAO {
  var listElementos = const [
    HelpLine(
        img: 'images/brasilreal.png', tex: 'Dados sobre a violência no Brasil'),
    HelpLine(
        img: 'images/nordestereal.png',
        tex: 'Dados sobre a violência no Nordeste'),
    HelpLine(
        img: 'images/megafonereal.png',
        tex: 'Faça sua denúncia',
        cor: Color(0xff9d0a00))
  ];

  Future<List<HelpLine>> findAll() async {
    await Future.delayed(Duration(seconds: 5));
    return listElementos;
  }
}
