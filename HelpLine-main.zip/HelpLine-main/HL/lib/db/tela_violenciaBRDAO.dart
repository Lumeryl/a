import 'package:flutter/material.dart';

class TelaViolenciabrDAO {
  final List<Widget> containers = [
    SizedBox(height: 15),
    Padding(
      padding: EdgeInsets.all(8),
      child: ElevatedButton(
        onPressed: () {
          // Lógica quando o botão for pressionado
        },
        style: ElevatedButton.styleFrom(
          primary: Color(0xFFECECEC),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        child: Row(
          children: [
            Image.asset("images/raça.png",
                height: 100, width: 100, fit: BoxFit.cover),
            SizedBox(
              width: 35,
            ),
            Expanded(
              child: Text(
                'Violência por Raça',
                style: TextStyle(fontSize: 20, color: Colors.black),
              ),
            ),
            SizedBox(
              width: 25,
            )
          ],
        ),
      ),
    ),
    SizedBox(height: 15),
    Padding(
      padding: EdgeInsets.all(8),
      child: ElevatedButton(
        onPressed: () {
          // Lógica quando o botão for pressionado
        },
        style: ElevatedButton.styleFrom(
          primary: Color(0xFFECECEC),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        child: Row(
          children: [
            Image.asset("images/genero.png",
                height: 100, width: 100, fit: BoxFit.cover),
            SizedBox(
              width: 35,
            ),
            Expanded(
              child: Text(
                'Violência por Gênero',
                style: TextStyle(fontSize: 20, color: Colors.black),
              ),
            ),
            SizedBox(
              width: 25,
            )
          ],
        ),
      ),
    ),
    SizedBox(
      height: 15,
    ),
    Padding(
      padding: EdgeInsets.all(8),
      child: ElevatedButton(
        onPressed: () {
          // Lógica quando o botão for pressionado
        },
        style: ElevatedButton.styleFrom(
          primary: Color(0xFFECECEC),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        child: Row(
          children: [
            Image.asset("images/transito.png",
                height: 100, width: 100, fit: BoxFit.cover),
            SizedBox(
              width: 35,
            ),
            Expanded(
              child: Text(
                'Violência no Trânsito',
                style: TextStyle(fontSize: 20, color: Colors.black),
              ),
            ),
            SizedBox(
              width: 25,
            )
          ],
        ),
      ),
    ),
    Padding(
      padding: EdgeInsets.all(8),
      child: ElevatedButton(
        onPressed: () {
          // Lógica quando o botão for pressionado
        },
        style: ElevatedButton.styleFrom(
          primary: Color(0xFFECECEC),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        child: Row(
          children: [
            Image.asset("images/sexual.png",
                height: 100, width: 100, fit: BoxFit.cover),
            SizedBox(
              width: 35,
            ),
            Expanded(
              child: Text(
                'Violência Sexual',
                style: TextStyle(fontSize: 20, color: Colors.black),
              ),
            ),
            SizedBox(
              width: 25,
            )
          ],
        ),
      ),
    ),
    Padding(
      padding: EdgeInsets.all(8),
      child: ElevatedButton(
        onPressed: () {
          // Lógica quando o botão for pressionado
        },
        style: ElevatedButton.styleFrom(
          primary: Color(0xFFECECEC),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        child: Row(
          children: [
            Image.asset("images/física.png",
                height: 100, width: 100, fit: BoxFit.cover),
            SizedBox(
              width: 35,
            ),
            Expanded(
              child: Text(
                'Violência Física',
                style: TextStyle(fontSize: 20, color: Colors.black),
              ),
            ),
            SizedBox(
              width: 25,
            )
          ],
        ),
      ),
    ),
    Padding(
      padding: EdgeInsets.all(8),
      child: ElevatedButton(
        onPressed: () {
          // Lógica quando o botão for pressionado
        },
        style: ElevatedButton.styleFrom(
          primary: Color(0xFFECECEC),
          shape: RoundedRectangleBorder(
            borderRadius: BorderRadius.circular(5),
          ),
        ),
        child: Row(
          children: [
            Image.asset("images/psicológica.png",
                height: 100, width: 100, fit: BoxFit.cover),
            SizedBox(
              width: 35,
            ),
            Expanded(
              child: Text(
                'Violência Psicológica',
                style: TextStyle(fontSize: 20, color: Colors.black),
              ),
            ),
            SizedBox(
              width: 25,
            )
          ],
        ),
      ),
    ),
  ];

  Future<List<Widget>> findAll() async {
    await Future.delayed(Duration(seconds: 5));
    return containers;
  }
}
