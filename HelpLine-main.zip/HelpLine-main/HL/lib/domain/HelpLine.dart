import 'package:flutter/material.dart';

class HelpLine {
  final String img;
  final String tex;
  final Color cor;

  const HelpLine(
      {required this.img, required this.tex, this.cor = Colors.black});
}
